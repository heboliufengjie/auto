var http = require('http');
var events = require('events'); // ??events??
var server = http.createServer();

server.on('request', function(req, res) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.write('shiyanlou,111');
    console.log('shiyanlou,111');
    res.end();
});

server.on('request', function(req, res) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.write('shiyanlou,222');
    console.log('shiyanlou,222');
    res.end();
});


server.on('request', function(req, res) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.write('shiyanlou,33');
    console.log('shiyanlou,333');
    res.end();
});

server.listen(1337, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1337/');

// ??server???'request'????????
var num = events.EventEmitter.listenerCount(server, 'request');
console.log(num);